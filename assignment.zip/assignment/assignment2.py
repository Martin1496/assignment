import os
import re
from collections import defaultdict

def get_words_from_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read()
        words = content.split()
        return words

def create_index(directory_path):
    text_files = [file for file in os.listdir(directory_path) if file.endswith(".txt")]
    file_paths = [os.path.join(directory_path, file) for file in text_files]
    exclude_words_file = os.path.join(directory_path, "exclude-words.txt")
    if os.path.isfile(exclude_words_file):
        exclude_words = set(get_words_from_file(exclude_words_file))
    else:
        exclude_words = set()
    index = defaultdict(list)
    for file_path in file_paths:
        words = get_words_from_file(file_path)
        page_number = extract_page_number(file_path)

        if page_number is not None:
            for word in words:
                if word not in exclude_words:
                    if page_number not in index[word]:
                        index[word].append(page_number)

    sorted_words = sorted(index.keys())
    output_file = os.path.join(directory_path, "index.txt")
    with open(output_file, 'w', encoding='utf-8') as file:
        for word in sorted_words:
            pages = ','.join(index[word])
            line = f"{word} : {pages}\n"
            file.write(line)
    print("Index created successfully.")
    return index

def extract_page_number(file_path):
    file_name = os.path.basename(file_path)
    match = re.search(r"Page(\d+)\.txt", file_name)
    if match:
        return match.group(1)
    else:
        return None
directory_path = input("Enter the directory path: ")
index = create_index(directory_path)
search_word = input("Enter a word to search: ")
if search_word in index:
    pages = ','.join(index[search_word])
    print(f"The word '{search_word}' is present in the following pages: {pages}")
else:
    print(f"The word '{search_word}' is not present in the folder.")

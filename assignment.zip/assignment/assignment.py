import os
from collections import Counter

def get_words_from_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        content = file.read()
        words = content.split()
        return words

def find_common_words(files):
    word_counts = Counter()
    for file in files:
        words = get_words_from_file(file)
        word_counts.update(words)
    common_words = [word for word, count in word_counts.items() if count > 1]
    return common_words

directory_path = input("Enter the directory path: ")

text_files = [file for file in os.listdir(directory_path) if file.endswith(".txt")]
file_paths = [os.path.join(directory_path, file) for file in text_files]
common_words = find_common_words(file_paths)
print("Common words:", common_words)
